import javax.swing.*;
import java.awt.*;
import javax.swing.text.*;
import java.util.*;
/*
 * Created on Apr 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author nmadnani
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class linePanel extends JPanel {

	private Document displayDocument;
	private java.util.List linesToDraw;
	
	public linePanel() {
		super();
		linesToDraw = new ArrayList();
	}
	
	public void setDisplayPoemDocument(Document doc) {
		displayDocument = doc;
	}
	
	public Document getDisplayPoemDocument() {
		return displayDocument;
	}
	
	public void drawLine(int x1, int y1, int x2, int y2, Color c, int width) {
		linesToDraw.add(new Line(x1,y1,x2,y2,c, width));
	}

	public void paintComponent(Graphics g) {
		Iterator lineiter = linesToDraw.iterator();
		int width;
		while(lineiter.hasNext()) {
			Line l = (Line)lineiter.next();
			g.setColor(l.c);
			width = l.x2 - l.x1;
			g.fillRect(l.x1, l.y1, width, l.fillWidth);
			//g.drawLine(l.x1, l.y1, l.x2, l.y2);
		}
	}
}

class Line {
	public int x1, y1, x2, y2;
	public Color c;
	public int fillWidth;
	
	public Line(int startx, int starty, int endx, int endy, Color clr, int w) {
		x1 = startx;
		y1 = starty;
		x2 = endx;
		y2 = endy;
		c = clr;
		fillWidth = w;
	}
}