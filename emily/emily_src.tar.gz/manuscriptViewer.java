import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.util.*;

import edu.umd.cs.piccolo.*;
import edu.umd.cs.piccolox.*;
import edu.umd.cs.piccolo.nodes.*;

/*
 * Created on Apr 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author nmadnani
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class manuscriptViewer extends JFrame {
	
	private java.util.List pagesToShow;
	private ListIterator showiter;
	private PCanvas manuscriptCanvas;
	private JScrollPane manuscriptCanvasScrollPane;
	private JButton nextButton;
	private JButton prevButton;
	private JPanel navPanel;
	private JTextField infoField;
	private PImage currentImage;
	
	public manuscriptViewer(Integer poemnum, xmlReader reader) {
		super("Manuscript Viewer");
		setSize(600,600);
		//setLocation(200,200);
		Container c = getContentPane();
		manuscriptCanvas = new PCanvas();
		manuscriptCanvasScrollPane = new JScrollPane(manuscriptCanvas);
		navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 10));
		navPanel.setPreferredSize(new Dimension(600, 50));
		prevButton = new JButton("<< PREV");
		prevButton.addActionListener(prevListener);
		String fn = (String)reader.fileNameHash.get(poemnum);
		Map imghash = (Map)reader.hashOfImageHashes.get(poemnum);
		Iterator imgiter = imghash.values().iterator();
		infoField = new JTextField("Page 1");
		nextButton = new JButton("NEXT >>");
		nextButton.addActionListener(nextListener);
		navPanel.add(prevButton);
		navPanel.add(infoField);
		navPanel.add(nextButton);
		pagesToShow = new ArrayList();
		
		while (imgiter.hasNext()) {
			Image manuImage = Toolkit.getDefaultToolkit().getImage(reader.srcFilePath.getParent() + "/images/" + imgiter.next() + ".jpg");
			//manuImage = manuImage.getScaledInstance(450, 550, Image.SCALE_SMOOTH);
			pagesToShow.add(new PImage(manuImage));
		}
		
		showiter = pagesToShow.listIterator();
		
		//PNode aNode = new PText("Hello World!");		

		if (pagesToShow.size() >= 1) {
			manuscriptCanvas.getLayer().addChild((PImage)showiter.next());
		}
		
		c.add(manuscriptCanvasScrollPane, BorderLayout.CENTER);
		c.add(navPanel, BorderLayout.SOUTH);
	}

	void nextPage() {
		if(showiter.hasNext()) {
			currentImage = (PImage)showiter.next();
			manuscriptCanvas.getLayer().removeAllChildren();
			manuscriptCanvas.getLayer().addChild(currentImage);
			manuscriptCanvas.getLayer().invalidatePaint();
		}
	}
	
	void prevPage() {
		if(showiter.hasPrevious()) {
			currentImage = (PImage)showiter.previous();
			manuscriptCanvas.getLayer().removeAllChildren();
			manuscriptCanvas.getLayer().addChild(currentImage);
			manuscriptCanvas.getLayer().invalidatePaint();
		}
	}
	
	ActionListener nextListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			nextPage();
		}
	};
	
	ActionListener prevListener = new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			prevPage();
		}
	};
	
}
