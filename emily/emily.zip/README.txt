This is the readme for the first prototype of Emily, the search and analysis tool
developed as part of a class project at the University of Maryland, College Park
in collaboration with the Human Computer Interaction Lab.

(c) Nitin Madnani, nmadnani@umiacs.umd.edu, Apr 2005

--------------------
System Requirements: 
--------------------

Java Runtime Environment (v 1.4.2 or later)
A Mac/PC
A minimum resolution of 1024 x 768 pixels

-----------------
1. Running Emily:
-----------------

If you are reading this file, you have already unzipped the zip archive into a directory. To run Emily,
double click on the "emily.jar" file in that directory. 

--------------------------
2. Loading data into Emily
--------------------------

Emily reads XML files that are encoded in the TEI specification and not any other XML files. Even within this domain, 
this version is very specific (being a prototype) and only reads in verse lines (<l>) from inside any line groups 
(<lg>) and also paragraphs (<p>). It does not yet index any person names or any other tags. 

To load any number of poems, start Emily, go to File->Open, browse to the directory that contains the xml files 
and select the XML Files that you want to open (standard ways to select multiple files with Shift-Click and Control-Clink 
work just fine) and click "Open". Emily then parses the XML files and once parsing is finished, it loads the data in both 
the document view and the overview. 

In order to be able to see the manuscript images in the image viewer, there should be an "images" directory at the
same level as the directory containing the xml files. This directory should contain the jpeg files for the manuscripts.

The parsing is really slow and, therefore, in order to speed up the loading time, Emily allows you to save the data you 
have loaded in a binary format on your hard disk. To do this, click File->Save, select the path where you would like 
to save this file, enter a file name and click "Save". 

--------------------
3. Configuring Emily
--------------------

Most of the coloring parameters of Emily can be configured in the provided file "emily.properties".

---------------------------
4. Setting up your own data
---------------------------

WARNING : Emily has not been tested with other TEI encoded XML data. It will probably work as long as the XML files are 
in proper format but it's not guaranteed !

If you need to set up your own data, create a separate directory with two subdirectories :

src/ - this contains the actual XML files
images/ - this contains the scanned images of the manuscripts of the documents (if any)

Then proceed as usual :

File->Open 			to parse the files and load the data for the first time
File->Save 			to save the loaded data in a binary format.
File->Load Existing Data 	to load existing saved binary data from the disk.

------
If you have any questions, email Nitin at nmadnani@umiacs.umd.edu 
