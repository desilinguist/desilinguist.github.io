import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.text.* ;

/*
 * Created on Apr 6, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author nmadnani
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class emily extends JFrame {

	private xmlReader reader;
	private JTabbedPane displayTabbedPane;
	private JPanel docViewPanel;
	private JScrollPane docViewScrollPane;
	private JPanel lineViewPanel;
	private JPanel filteredLineViewPanel;
	
	private Map docTextPanels;
	private Map docLinePanels;
	
	private static String propertiesFilename = "emily.properties";
	
	private Box statusPanel;
	private JTextField statusText;
	private JProgressBar pb;
	private JButton cancelButton;
	
	private JPanel mainPanel;
	
	private JTabbedPane searchPanel;
	private Box wordSearchPanel;
	private JTextField wordSearchField;
	private JCheckBox hideNonHitsBox;
	private JCheckBox removeNonHitsBox;
	private JRadioButton colorUsingWords;
	private JRadioButton colorUsingWeights;
	private String searchMode;
	private JButton wordSearchButton;
	private JButton clearSearchButton;
	private JPanel poemPanel;
	private JTextPane poemTextArea;
	private Box sidePanel;
	private JTextPane searchLegendPane;
	
	private JPanel displayPanel;
	
	private java.util.List showList;
	private Map searchResultsHash;
	private java.util.List searchTerms;
	private java.util.List searchTermWeights;
	private java.util.List searchColorList;
	
	private int displayMode;
	
	SwingWorker worker;
	SwingWorker searcher;
	SwingWorker saver;
	SwingWorker clearer;
	SwingWorker loader;

	private int eachHeight;
	private int eachWidth;
	private int lineWidth;
	private int rectFillWidth;
	private int initRows;
	private int numRows;
	
	layoutParameters fullLayout;
	layoutParameters searchFilteredLayout;
	
	MutableAttributeSet normalAttr = new SimpleAttributeSet();
	MutableAttributeSet searchAttr = new SimpleAttributeSet();
	MutableAttributeSet regionAttr = new SimpleAttributeSet();

	MutableAttributeSet displayPoemAttr = new SimpleAttributeSet();
	MutableAttributeSet displayPoemSearchAttr = new SimpleAttributeSet();
	
	JFileChooser chooser;
	
	boolean searchByWeightDisplay;
	boolean searchByWordDisplay;
	boolean resetDisplay;
	boolean clearSearchDisplay;
	boolean hideNonMatchesDisplay;
	boolean removedNonMatchesDisplay;
	boolean hideOptionSet;
	boolean removeOptionSet;
	
	Color poemBackgroundColor;
	Color poemBleedColor;
	Color poemLineColor;
	Color poemPanelColor;
	Color searchLineColor;
	
	
	public emily() {
		//Create the JFrame
		super("Emily");
		setSize(800,600);
		this.setLocation(100,100);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
				
		showList = new ArrayList();
		docTextPanels = new TreeMap();
		docLinePanels = new TreeMap();
		Container content = getContentPane();
		
		File propsFile = new File(propertiesFilename);
		Properties props = new Properties();
		try {
			props.load(new FileInputStream(propsFile));
		}
		catch(IOException e) {
			System.out.println("Could not find properties file: " + propertiesFilename);
			System.exit(1);
		}
		
		poemBackgroundColor = parseColor(props.getProperty("POEM_BGND_COLOR"));
		poemPanelColor = parseColor(props.getProperty("POEM_PANEL_COLOR"));
		poemLineColor = parseColor(props.getProperty("POEM_LINE_COLOR"));
		poemBleedColor = parseColor(props.getProperty("POEM_BLEED_COLOR"));
		
		initRows = Integer.parseInt(props.getProperty("INITIAL_ROWS"));
				
		StyleConstants.setFontFamily(normalAttr, "Roman");
		StyleConstants.setFontSize(normalAttr, 9);
		StyleConstants.setForeground(normalAttr, Color.black);
		StyleConstants.setBold(normalAttr, false);

		StyleConstants.setFontFamily(searchAttr, "Roman");
		StyleConstants.setFontSize(searchAttr, 9);
		//StyleConstants.setForeground(searchAttr, Color.red);
		//StyleConstants.setBackground(searchAttr, Color.lightGray);
		StyleConstants.setBold(searchAttr, false);

		StyleConstants.setFontFamily(displayPoemAttr, "Roman");
		StyleConstants.setFontSize(displayPoemAttr, 14);
		StyleConstants.setForeground(displayPoemAttr, Color.black);
		StyleConstants.setBold(displayPoemAttr, false);

		StyleConstants.setFontFamily(displayPoemSearchAttr, "Roman");
		StyleConstants.setFontSize(displayPoemSearchAttr, 14);
		//StyleConstants.setForeground(displayPoemSearchAttr, Color.red);
		//StyleConstants.setBackground(displayPoemSearchAttr, Color.lightGray);
		StyleConstants.setBold(displayPoemSearchAttr, true);

		resetDisplay = true;
		searchByWordDisplay = false;
		searchByWeightDisplay = false;
		clearSearchDisplay = false;
		hideNonMatchesDisplay = false;
		hideOptionSet = false;
		searchResultsHash = new TreeMap();

		searchTerms = new ArrayList();
		searchTermWeights = new ArrayList();
		
		searchColorList = new ArrayList();
		searchColorList.add(Color.red);
		searchColorList.add(Color.blue);
		searchColorList.add(Color.green);

		//Three panels:
		// iconPanel : where all document icons go (inside just a scroll pane)
		// statusPanel : will have a status text field and a progress bar
		// sidePanel : will have two panels, one for showing the poem and
		//             a tabbed pane for searching 
		
		mainPanel = new JPanel(new BorderLayout());
		mainPanel.setPreferredSize(new Dimension(800,600));
		
		// The iconPanel with a scroll pane
		//iconPanel = new JPanel(new GridLayout(0, 8));
		displayTabbedPane = new JTabbedPane();
		
		docViewPanel = new JPanel(new FlowLayout(FlowLayout.CENTER,2,2));
		docViewPanel.setBackground(Color.white);
		docViewPanel.setMaximumSize(new Dimension(500,20000));
		docViewPanel.setPreferredSize(new Dimension(500,20000));
		docViewScrollPane = new JScrollPane(docViewPanel, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		lineViewPanel = new JPanel(new GridLayout(3,0));
		lineViewPanel.setBackground(poemBackgroundColor);

		filteredLineViewPanel = new JPanel(new GridLayout(2,0));
		filteredLineViewPanel.setBackground(poemBackgroundColor);
		
		displayTabbedPane.addTab("Document View", docViewScrollPane);
		displayTabbedPane.addTab("Overview", lineViewPanel);
		
		// The statusPanel 
		statusPanel = Box.createHorizontalBox();
		statusPanel.setPreferredSize(new Dimension(800, 25));
		statusText = new JTextField("Ready.");
		statusText.setEditable(false);
		statusText.setPreferredSize(new Dimension(600,25));
		statusPanel.add(statusText);
		pb = new JProgressBar();
		//pb.setPreferredSize(new Dimension(150,25));
		statusPanel.add(pb);
		cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(cancelListener);
		cancelButton.setEnabled(false);
		statusPanel.add(cancelButton);

		// The sidePanel
		sidePanel = Box.createVerticalBox();
		sidePanel.setPreferredSize(new Dimension(300, 575));
		
		//Add the poem panel
		//poemPanel = new JPanel();
		//poemPanel.setPreferredSize(new Dimension(300,300));
		//poemTextArea = new JTextArea("Welcome to Emily.");
		poemTextArea = new JTextPane();
		poemTextArea.setSize(300, 1000);
		poemTextArea.setEditable(false);
		//poemTextArea.setLineWrap(true);
		JScrollPane poemPanel = new JScrollPane(poemTextArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		poemPanel.setPreferredSize(new Dimension(300, 250));
		//poemPanel.add(poemPanel);
		sidePanel.add(poemPanel);
		
		//Add the search panel	
		
		JTabbedPane searchPanel = new JTabbedPane();
		searchPanel.setPreferredSize(new Dimension(300,250));
		
		wordSearchPanel = Box.createVerticalBox();
		wordSearchField = new JTextField("");
		wordSearchField.setAlignmentX(Component.CENTER_ALIGNMENT);
		wordSearchField.setMaximumSize(new Dimension(300, 25));
		
		searchLegendPane = new JTextPane();
		searchLegendPane.setBackground(new Color(240, 240, 240));
		searchLegendPane.setEditable(false);
		JPanel searchLegendPanel = new JPanel();
		searchLegendPanel.add(searchLegendPane);
		searchLegendPanel.setBorder(BorderFactory.createTitledBorder("Search Legend"));
		searchLegendPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

		
		hideNonHitsBox = new JCheckBox("Only Display Matches in Overview ", false);
		hideNonHitsBox.setAlignmentX(Component.CENTER_ALIGNMENT);
		hideNonHitsBox.setName("hide");
		removeNonHitsBox = new JCheckBox("Show New Filtered View", false);
		removeNonHitsBox.setAlignmentX(Component.CENTER_ALIGNMENT);
		removeNonHitsBox.setName("remove");
		hideNonHitsBox.addItemListener(new hideNonHitsListener());
		removeNonHitsBox.addItemListener(new removeNonHitsListener());
		hideNonHitsBox.setEnabled(false);
		removeNonHitsBox.setEnabled(false);

		JPanel searchResultsOptionsPanel = new JPanel();
		searchResultsOptionsPanel.add(hideNonHitsBox);
		searchResultsOptionsPanel.add(removeNonHitsBox);
		searchResultsOptionsPanel.setBorder(BorderFactory.createTitledBorder("Configure Results Display"));
		searchResultsOptionsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		JPanel searchColorOptionsPanel = new JPanel();
		ButtonGroup colorButtonGroup = new ButtonGroup();
		
		colorUsingWords = new JRadioButton("Search Terms");
		colorUsingWords.setAlignmentX(Component.LEFT_ALIGNMENT);
		colorUsingWords.addItemListener(new searchOptionsListener());
		colorUsingWords.setActionCommand("words");
		colorUsingWords.setEnabled(false);
		
		colorUsingWeights = new JRadioButton("Combined Weight");
		colorUsingWeights.setAlignmentX(Component.LEFT_ALIGNMENT);
		colorUsingWeights.setActionCommand("weights");
		colorUsingWeights.addItemListener(new searchOptionsListener());
		colorUsingWeights.setEnabled(false);
		
		//Set default Search mode to weights
		searchMode = "weights";
		
		colorButtonGroup.add(colorUsingWords);
		colorButtonGroup.add(colorUsingWeights);
		searchColorOptionsPanel.add(colorUsingWords);
		searchColorOptionsPanel.add(colorUsingWeights);
		searchColorOptionsPanel.setBorder(BorderFactory.createTitledBorder("Color by:"));
		searchColorOptionsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		wordSearchButton = new JButton("Search");
		clearSearchButton = new JButton("Clear Search");
		JPanel searchButtonsPanel = new JPanel();
		wordSearchButton.addActionListener(new wordSearchListener());
		clearSearchButton.addActionListener(new clearSearchListener());				
		wordSearchButton.setEnabled(false);			
		clearSearchButton.setEnabled(false);
		searchButtonsPanel.add(wordSearchButton);
		searchButtonsPanel.add(clearSearchButton);
		searchButtonsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		wordSearchPanel.add(wordSearchField);
		//wordSearchPanel.add(showHitsOnlyBox);
//		wordSearchPanel.add(hideNonHitsBox);
//		wordSearchPanel.add(removeNonHitsBox);
		wordSearchPanel.add(searchButtonsPanel);
		wordSearchPanel.add(searchLegendPanel);
		wordSearchPanel.add(searchColorOptionsPanel);
		wordSearchPanel.add(searchResultsOptionsPanel);
				
		searchPanel.addTab("Search", wordSearchPanel);
		
		sidePanel.add(searchPanel);
		//mainPanel.add(iconPanel, BorderLayout.CENTER);
		mainPanel.add(displayTabbedPane, BorderLayout.CENTER);
		mainPanel.add(sidePanel, BorderLayout.EAST);
		mainPanel.add(statusPanel, BorderLayout.SOUTH);
				
		content.add(mainPanel);
				
		//Add a menubar
		JMenuBar bar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		bar.add(fileMenu);
		JMenuItem fileItem = new JMenuItem("Open");
		fileItem.setAccelerator(KeyStroke.getKeyStroke('O', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));
		fileItem.addActionListener(new openListener());
		fileMenu.add(fileItem);
		
		JMenuItem loadItem = new JMenuItem("Load Existing Data");
		loadItem.setAccelerator(KeyStroke.getKeyStroke('L', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));
		loadItem.addActionListener(new loadListener());
		fileMenu.add(loadItem);

		
		JMenuItem saveItem = new JMenuItem("Save Current Data");
		saveItem.setAccelerator(KeyStroke.getKeyStroke('S', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));
		saveItem.addActionListener(new saveListener());
		fileMenu.add(saveItem);
		
		
		exitAction ea = new exitAction("Exit",new ImageIcon("exit.gif"));
		JMenuItem exitItem = new JMenuItem(ea);
		exitItem.setAccelerator(KeyStroke.getKeyStroke('Q', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));
		fileMenu.add(exitItem);
		getRootPane().setJMenuBar(bar);
		
		displayMode = 0;
		setExtendedState(JFrame.MAXIMIZED_BOTH);
	}
	
	Color parseColor(String rgbString) {
		if(rgbString.equals("")) {
			System.out.println("Cannot make color from an empty string. Defaulting to white.");
			return Color.white;
		}
		else {
			String[] components = rgbString.split(",");
			if(components.length != 3) {
				System.out.println("Invalid color string. Defaulting to white.");
				return Color.white;
			}
			else {
				int redVal = Integer.parseInt(components[0]);
				int greenVal = Integer.parseInt(components[1]);
				int blueVal = Integer.parseInt(components[2]);
				return new Color(redVal, greenVal, blueVal);
			}
		}
	}
	
	public static void main(String[] args) {
		emily em = new emily();
		em.setVisible(true);
	}
	
	void updateStatus(final int i){
		Runnable doSetProgressBarValue = new Runnable() {
			public void run() {
				pb.setValue(i);
			}
		};
		SwingUtilities.invokeLater(doSetProgressBarValue);
	}
	
	void setUpApp(final int numXmlFiles) {
		Runnable initAppElements = new Runnable() {
			public void run() {
				statusText.setText("Parsing selected xml files ...");
				cancelButton.setEnabled(true);
				poemTextArea.setText("");
				pb.setMaximum(numXmlFiles);
			}
		};
		SwingUtilities.invokeLater(initAppElements);
	}

	
	Color calculateRedLevel(int lineweight) {
		//Assuming that the maximum weight (number of word matches)
		// in a line can be 15, then the range [1,5] can be mapped 
		// on to the range [0,255] (for Red) as follows :
		// colorValue = givenLineWeight * 51 (since 255/5 = 51)
		//But we want to saturate at either end, therefore, 
		// finalColorValue = min(max(colorValue, 0), 255);
		
		// This should be a preference option but I didn't have time
		// to make it that. A to-do for version 0.01.
		if(lineweight < 3) {
			return new Color(lineweight*85, 0, 0);
		}
		else {
			return new Color(255, 0, 0);
		}
	}
	
	void restoreLayout(layoutParameters lp) {
		eachWidth = lp.eachWidth;
		eachHeight = lp.eachHeight;
		lineWidth = lp.lineWidth;
		numRows = lp.numRows;
		rectFillWidth = lp.rectFillWidth;
		lineViewPanel.setLayout(new GridLayout(numRows,0));
	}
	
	void updateDisplays(){
		
		int numdocs;
		
		int offset;
		java.util.List ll;
		ListIterator li;
		String s;
		int verticalLineOffset;
		int fverticalLineOffset;

		
		if(showList.size() > 0) {
			
			if(searchByWeightDisplay) {

				weightedPositionList searchwpl;
				Collection pnset = searchResultsHash.keySet();
				java.util.List searchpns = new ArrayList(pnset);
				
				restoreLayout(fullLayout);				
				//lineWidth = eachWidth - 1;
				
				int fnumdocs = searchpns.size();				
				int fnumRows = initRows;
				int feachWidth = initRows * (lineViewPanel.getWidth() / fnumdocs) ;
				int feachHeight = lineViewPanel.getHeight() / initRows;
				
				if(feachWidth >= 100) {
					fnumRows = 1;
				}
				else if(feachWidth > 15 & eachWidth <= 30) {
					fnumRows += 1;
				}
				else if(feachWidth <= 15) {
					fnumRows += 2;
				}
									
				feachWidth = fnumRows * (lineViewPanel.getWidth() / fnumdocs) ;
				feachHeight  = lineViewPanel.getHeight() / fnumRows;
				
				filteredLineViewPanel.setLayout(new GridLayout(fnumRows,0));				
				int flineWidth = feachWidth - 1;
				
				//Also calculate how wide each line needs to be drawn 
				// That will be decided on the basis of the longest poem.
				
				int maxLength = 0;
				for(int i=0; i < fnumdocs; i++) {
					Integer currlength = (Integer)reader.hashOfPoemLengths.get(showList.get(i));
					maxLength = Math.max(maxLength, currlength.intValue());
				}
				
				float tmp = (float)feachHeight/(float)maxLength;
				int frectFillWidth = Math.round(tmp);
				
				for(int i=0; i<showList.size(); i++) {
					if(pnset.contains(showList.get(i))) {
						Set bleeders = new LinkedHashSet();
						searchwpl = (weightedPositionList)searchResultsHash.get(showList.get(i));
						docPane thisDocPane = (docPane)docTextPanels.get(showList.get(i));
						linePanel thisLinePanel = (linePanel)docLinePanels.get(showList.get(i));
						linePanel fLinePanel = new linePanel();
						fLinePanel.setName(String.valueOf(i+1));
						fLinePanel.setToolTipText((String)reader.fileNameHash.get(showList.get(i)));
						fLinePanel.addMouseListener(docLineMouseListener);
						fLinePanel.setBackground(poemPanelColor);
						fLinePanel.setBorder(BorderFactory.createLineBorder(poemBackgroundColor));

						Document doc = new DefaultStyledDocument();
						Document displayDoc = new DefaultStyledDocument();
						java.util.List searchpositions = searchwpl.getPositions();
						ll = (java.util.List)reader.hashOfLineLists.get(showList.get(i));
						li = ll.listIterator();
						verticalLineOffset = 0;
						fverticalLineOffset = 0;
						while(li.hasNext()) {
							try {								
								Integer currlinenum = new Integer(li.nextIndex()+1);
								if(searchpositions.contains(currlinenum)) {
									bleeders.remove(currlinenum);
									int weight = searchwpl.getWeight(currlinenum);
									int numbleeders;
									if((weight % 3) == 0) {
										numbleeders = (weight / 3) - 1;
									}
									else {
										numbleeders = (weight / 3);
									}
									for(int k=1; k<=numbleeders; k++) {
										bleeders.add(new Integer(currlinenum.intValue()+k));
									}
								
									thisLinePanel.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, calculateRedLevel(weight), rectFillWidth);
									fLinePanel.drawLine(1, 1+fverticalLineOffset, flineWidth, 1+fverticalLineOffset, calculateRedLevel(weight), frectFillWidth);
									s = (String)li.next();
									String[] words = s.split("\\s+");
									for(int j=0; j<words.length; j++)
									{
										offset = doc.getLength();
										String currword = words[j].toLowerCase();
										if(searchTerms.contains(currword)) {
//											System.out.println("Adding " + words[j] + " in search color " + searchColorList.get(searchTerms.indexOf(currword)).toString());
											StyleConstants.setForeground(searchAttr,(Color)searchColorList.get(searchTerms.indexOf(currword)));
											StyleConstants.setForeground(displayPoemSearchAttr,(Color)searchColorList.get(searchTerms.indexOf(currword)));
											doc.insertString(offset, words[j] + " ", searchAttr);
											displayDoc.insertString(offset, words[j] + " ", displayPoemSearchAttr);
										}
										else {
//											System.out.println("Adding " + words[j] + " in normal color");
											doc.insertString(offset, words[j] + " ", normalAttr);
											displayDoc.insertString(offset, words[j] + " ", displayPoemAttr);
										}
									}
									offset = doc.getLength();
									doc.insertString(offset, "\n", normalAttr);
									displayDoc.insertString(offset, "\n", displayPoemAttr);
								}
								else {
									if(bleeders.contains(currlinenum)) {
										thisLinePanel.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, poemBleedColor, rectFillWidth);
										fLinePanel.drawLine(1, 1+fverticalLineOffset, flineWidth, 1+fverticalLineOffset, poemBleedColor, frectFillWidth);
										bleeders.remove(currlinenum);
									}
									else {
										thisLinePanel.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, poemLineColor, rectFillWidth);
										fLinePanel.drawLine(1, 1+fverticalLineOffset, flineWidth, 1+fverticalLineOffset, poemLineColor, frectFillWidth);
									}

									offset = doc.getLength();
									s = (String)li.next(); 
									doc.insertString(offset, s + "\n", normalAttr);
									displayDoc.insertString(offset, s + "\n", displayPoemAttr);
								}
								verticalLineOffset += rectFillWidth;
								fverticalLineOffset += frectFillWidth;
							}
							catch(BadLocationException ble) {
								System.out.println(doc.getLength());
								System.out.println("Bad offset: " +ble.offsetRequested());
								System.exit(1);
							}
						}
						thisDocPane.setPoemDocument(doc);
						thisDocPane.setDisplayPoemDocument(displayDoc);
						thisLinePanel.setDisplayPoemDocument(displayDoc);
						fLinePanel.setDisplayPoemDocument(displayDoc);
						filteredLineViewPanel.add(fLinePanel);
					}
				}
			}
			if(searchByWordDisplay) {

				weightedPositionList searchwpl;
				Collection pnset = searchResultsHash.keySet();
				java.util.List searchpns = new ArrayList(pnset);
				
				restoreLayout(fullLayout);				
				//lineWidth = eachWidth - 1;
				
				int fnumdocs = searchpns.size();				
				int fnumRows = initRows;
				int feachWidth = initRows * (lineViewPanel.getWidth() / fnumdocs) ;
				int feachHeight = lineViewPanel.getHeight() / initRows;
				
				if(feachWidth >= 100) {
					fnumRows = 1;
				}
				else if(feachWidth > 15 & eachWidth <= 30) {
					fnumRows += 1;
				}
				else if(feachWidth <= 15) {
					fnumRows += 2;
				}
									
				feachWidth = fnumRows * (lineViewPanel.getWidth() / fnumdocs) ;
				feachHeight  = lineViewPanel.getHeight() / fnumRows;
				
				filteredLineViewPanel.setLayout(new GridLayout(fnumRows,0));				
				int flineWidth = feachWidth - 1;
				
				//Also calculate how wide each line needs to be drawn 
				// That will be decided on the basis of the longest poem.
				
				int maxLength = 0;
				for(int i=0; i < fnumdocs; i++) {
					Integer currlength = (Integer)reader.hashOfPoemLengths.get(showList.get(i));
					maxLength = Math.max(maxLength, currlength.intValue());
				}
				
				float tmp = (float)feachHeight/(float)maxLength;
				int frectFillWidth = Math.round(tmp);
				
				for(int i=0; i<showList.size(); i++) {
					if(pnset.contains(showList.get(i))) {
						searchwpl = (weightedPositionList)searchResultsHash.get(showList.get(i));
						docPane thisDocPane = (docPane)docTextPanels.get(showList.get(i));
						linePanel thisLinePanel = (linePanel)docLinePanels.get(showList.get(i));
						linePanel fLinePanel = new linePanel();
						fLinePanel.setName(String.valueOf(i+1));
						fLinePanel.setToolTipText((String)reader.fileNameHash.get(showList.get(i)));
						fLinePanel.addMouseListener(docLineMouseListener);
						fLinePanel.setBackground(poemPanelColor);
						fLinePanel.setBorder(BorderFactory.createLineBorder(poemBackgroundColor));

						Document doc = new DefaultStyledDocument();
						Document displayDoc = new DefaultStyledDocument();
						java.util.List searchpositions = searchwpl.getPositions();
						ll = (java.util.List)reader.hashOfLineLists.get(showList.get(i));
						li = ll.listIterator();
						verticalLineOffset = 0;
						fverticalLineOffset = 0;
						while(li.hasNext()) {
							try {
								Integer currlinenum = new Integer(li.nextIndex()+1);
								if(searchpositions.contains(currlinenum)) {
									int weight = searchwpl.getWeight(currlinenum);
									// If the weight of the line is greater than any of the search term weights
									// that means that there are multiple matches in this line and therefore,
									// it will be colored purple. 
									s = (String)li.next();
									String[] words = s.split("\\s+");
									for(int j=0; j<words.length; j++)
									{
										offset = doc.getLength();
										String currword = words[j].toLowerCase();
										if(searchTerms.contains(currword)) {
											if(weight > 1) {
												thisLinePanel.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, new Color(255,0,255) , rectFillWidth);
												fLinePanel.drawLine(1, 1+fverticalLineOffset, flineWidth, 1+fverticalLineOffset, new Color(255,0,255), frectFillWidth);

											}
											else {
												thisLinePanel.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, (Color)searchColorList.get(searchTerms.indexOf(currword)), rectFillWidth);
												fLinePanel.drawLine(1, 1+fverticalLineOffset, flineWidth, 1+fverticalLineOffset, (Color)searchColorList.get(searchTerms.indexOf(currword)), frectFillWidth);
											}
//											System.out.println("Adding " + words[j] + " in search color " + searchColorList.get(searchTerms.indexOf(currword)).toString());
											StyleConstants.setForeground(searchAttr,(Color)searchColorList.get(searchTerms.indexOf(currword)));
											StyleConstants.setForeground(displayPoemSearchAttr,(Color)searchColorList.get(searchTerms.indexOf(currword)));
											doc.insertString(offset, words[j] + " ", searchAttr);
											displayDoc.insertString(offset, words[j] + " ", displayPoemSearchAttr);
										}
										else {
//											System.out.println("Adding " + words[j] + " in normal color");
											doc.insertString(offset, words[j] + " ", normalAttr);
											displayDoc.insertString(offset, words[j] + " ", displayPoemAttr);
										}
									}
									offset = doc.getLength();
									doc.insertString(offset, "\n", normalAttr);
									displayDoc.insertString(offset, "\n", displayPoemAttr);
								}
								else {
									thisLinePanel.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, poemLineColor, rectFillWidth);
									fLinePanel.drawLine(1, 1+fverticalLineOffset, flineWidth, 1+fverticalLineOffset, poemLineColor, frectFillWidth);

									offset = doc.getLength();
									s = (String)li.next(); 
									doc.insertString(offset, s + "\n", normalAttr);
									displayDoc.insertString(offset, s + "\n", displayPoemAttr);
								}
								verticalLineOffset += rectFillWidth;
								fverticalLineOffset += frectFillWidth;
							}
							catch(BadLocationException ble) {
								System.out.println(doc.getLength());
								System.out.println("Bad offset: " +ble.offsetRequested());
								System.exit(1);
							}
						}
						thisDocPane.setPoemDocument(doc);
						thisDocPane.setDisplayPoemDocument(displayDoc);
						thisLinePanel.setDisplayPoemDocument(displayDoc);
						fLinePanel.setDisplayPoemDocument(displayDoc);
						filteredLineViewPanel.add(fLinePanel);
					}
				}
			}
			else if (hideNonMatchesDisplay) {
				Collection pnset = searchResultsHash.keySet();
				for(int i=0; i<showList.size(); i++) {
					if(!pnset.contains(showList.get(i))) {
						linePanel lp = (linePanel)docLinePanels.get(showList.get(i));
						if(hideOptionSet)
							lp.setVisible(false);
						else
							lp.setVisible(true);
					}
				}
			}
			
			else if(removedNonMatchesDisplay) {
				displayTabbedPane.addTab("Filtered Overview",filteredLineViewPanel);
				displayTabbedPane.revalidate();
				displayTabbedPane.repaint();
			}
			else if(clearSearchDisplay) {

				Collection pnset = searchResultsHash.keySet();
				//java.util.List searchpns = new ArrayList(pnset);
				
				restoreLayout(fullLayout);
				for(int i=0; i<showList.size(); i++) {
					if(pnset.contains(showList.get(i))) {
						weightedPositionList swpl = (weightedPositionList)searchResultsHash.get(showList.get(i));
						docPane thisDocPane = (docPane)docTextPanels.get(showList.get(i));
						linePanel thisLinePanel = (linePanel)docLinePanels.get(showList.get(i));
						Document doc = new DefaultStyledDocument();
						Document displayDoc = new DefaultStyledDocument();
						java.util.List searchpositions = swpl.getPositions();
						ll = (java.util.List)reader.hashOfLineLists.get(showList.get(i));
						li = ll.listIterator();
						verticalLineOffset = 0;

						while(li.hasNext()) {
							try {
								thisLinePanel.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, poemLineColor, rectFillWidth);
								offset = doc.getLength();
								s = (String)li.next();
								doc.insertString(offset, s + "\n", normalAttr);
								displayDoc.insertString(offset, s + "\n", displayPoemAttr);
							}
							catch(BadLocationException ble) {
								ble.printStackTrace();
							}
							verticalLineOffset += rectFillWidth;
						}
						//thisDocPanel.setPoemBackground(Color.white);
						thisDocPane.setPoemDocument(doc);
						thisDocPane.setDisplayPoemDocument(displayDoc);
						thisLinePanel.setDisplayPoemDocument(displayDoc);
						thisLinePanel.setVisible(true);
					}
				}
				for(int i=0; i<showList.size(); i++) {
					linePanel lp = (linePanel)(linePanel)docLinePanels.get(showList.get(i));
					lp.setVisible(true);
					lineViewPanel.add(lp);
				}
			}
			
			else if (resetDisplay){				
				numdocs = showList.size();
				
				if(!docTextPanels.isEmpty() & !docLinePanels.isEmpty()) {
					Iterator dti = docTextPanels.keySet().iterator();
					Iterator dli = docLinePanels.keySet().iterator();
					while(dti.hasNext()) {
						docPane dp = (docPane)dti.next();
						JPanel docTextPanel = (JPanel)dp.getParent();
						//docTextPanel.setBackground(Color.white);
						//docButtonPanel.add((docPane)docTextPanels.get(dti.next()));
						docViewPanel.add(docTextPanel);
					}
					while(dli.hasNext()) {
						linePanel lp = (linePanel)docLinePanels.get(dli.next());
						lineViewPanel.add(lp);
					}
				}
				else {					
					//Here's where (relatively) intelligent layout happens
					// We have started out with the given number of rows so now increase or
					// decrease depending on how many documents we are visualizing.
					
					numRows = initRows;					
					eachWidth = initRows * (lineViewPanel.getWidth() / numdocs) ;
					eachHeight = lineViewPanel.getHeight() / initRows;

					if(eachWidth >= 100) {
						numRows = 1;
					}
					else if(eachWidth > 15 & eachWidth <=30 ) {
						numRows += 1;
					}
					else if(eachWidth <= 15) {
						numRows += 2;
					}
										
					eachWidth = numRows * (lineViewPanel.getWidth() / numdocs) ;
					eachHeight  = lineViewPanel.getHeight() / numRows;
					lineViewPanel.setLayout(new GridLayout(numRows,0));
					lineWidth = eachWidth - 1;
					
					//Also calculate how wide each line needs to be drawn 
					// That will be decided on the basis of the longest poem.
					
					int maxLength = 0;
					for(int i=0; i < numdocs; i++) {
						Integer currlength = (Integer)reader.hashOfPoemLengths.get(showList.get(i));
						maxLength = Math.max(maxLength, currlength.intValue());
					}
					float tmp = (float)eachHeight/(float)maxLength;
					rectFillWidth = Math.round(tmp);
					
					fullLayout = new layoutParameters(eachWidth, eachHeight, lineWidth, rectFillWidth, numRows); 
										
					for(int i=0; i<showList.size(); i++) {
						docPane dp = new docPane();
						linePanel lp = new linePanel();
						Document doc = new DefaultStyledDocument();
						Document displayDoc = new DefaultStyledDocument();
						ll = (java.util.List)reader.hashOfLineLists.get(showList.get(i));
						li = ll.listIterator();
						try {
							verticalLineOffset = 0;
							while(li.hasNext()) {
								offset = doc.getLength();
								s = (String)li.next();
								lp.drawLine(1, 1+verticalLineOffset, lineWidth, 1+verticalLineOffset, poemLineColor, rectFillWidth);
								doc.insertString(offset, s + "\n", normalAttr);
								displayDoc.insertString(offset, s + "\n", displayPoemAttr);
								verticalLineOffset += rectFillWidth;
							}						
						}
						catch(BadLocationException ble) {
							ble.printStackTrace();
						}
						dp.setPoemDocument(doc);
						dp.setDisplayPoemDocument(displayDoc);
						lp.setDisplayPoemDocument(displayDoc);
						dp.setEditable(false);
//						dp.setDocument(doc);
						JPanel docButtonPanel = new JPanel();
						dp.setName(String.valueOf(i+1));
						lp.setName(String.valueOf(i+1));
						
						dp.setToolTipText((String)reader.fileNameHash.get(showList.get(i)));
						lp.setToolTipText((String)reader.fileNameHash.get(showList.get(i)));

						dp.addMouseListener(docTextMouseListener);
						lp.addMouseListener(docLineMouseListener);

						docButtonPanel.setBackground(Color.white);
						lp.setBackground(poemPanelColor);
						
						docButtonPanel.setBorder(BorderFactory.createLineBorder(Color.white));
						lp.setBorder(BorderFactory.createLineBorder(poemBackgroundColor));
						
						docButtonPanel.add(dp);
						
						docTextPanels.put(showList.get(i), dp);
						docLinePanels.put(showList.get(i), lp);

						dp.addFocusListener(new emilyFocusListener());
						lp.addFocusListener(new emilyFocusListener());
						
						//docButtonPanel.add(docPane);
						//docArea.addFocusListener(docButtonFocusListener);
						
						docViewPanel.add(docButtonPanel);
						lineViewPanel.add(lp);
					}
				}
			}
		}
		docViewPanel.revalidate();
		docViewPanel.repaint();
		lineViewPanel.revalidate();
		lineViewPanel.repaint();
	}
		
	
	Map combineWordHashes(Map mainHash, Map toAddHash, int scaleFactor) {
		Iterator ki = toAddHash.keySet().iterator();
		while(ki.hasNext()) {
			Object currkey = ki.next();
			if(mainHash.containsKey(currkey)) {
				weightedPositionList wpl1 = new weightedPositionList((weightedPositionList)mainHash.get(currkey));
				weightedPositionList wpl2 = new weightedPositionList((weightedPositionList)toAddHash.get(currkey));
				
				wpl1.combine(wpl2, scaleFactor);
				mainHash.put(currkey, wpl1);
			}
			else {
				weightedPositionList wpl1 = new weightedPositionList((weightedPositionList)toAddHash.get(currkey), scaleFactor);
				mainHash.put(currkey, wpl1);
			}
		}
		return mainHash;
	}
	
	Object doOpenNew(File xmlPath, File[] xmlFileList){
		try {
			setUpApp(xmlFileList.length);
			docViewPanel.removeAll();
			lineViewPanel.removeAll();
			showList.clear();
			docTextPanels.clear();
			docLinePanels.clear();
			resetDisplay = true;
			searchByWeightDisplay = false;
			searchByWordDisplay = false;
			clearSearchDisplay = false;
			searchResultsHash.clear();
			searchTerms.clear();
			reader = new xmlReader();
			reader.setNumberOfDocuments(xmlFileList.length);
			for(int i=0; i<xmlFileList.length; i++) {
				updateStatus(i+1);
				if (Thread.interrupted()) {
					throw new InterruptedException();
				}
				reader.readXML(xmlPath, xmlFileList[i], i);
				showList.add(new Integer(i+1));
			}
 		}
		catch (InterruptedException e) {
			updateStatus(0);
			return "Cancelled.";
		}
		catch (RuntimeException e) {
			e.printStackTrace();
			System.exit(1);
		}
		cancelButton.setEnabled(false);
		colorUsingWords.setEnabled(false);
		colorUsingWeights.setEnabled(true);
		wordSearchButton.setEnabled(true);
		wordSearchField.setText("");
		updateStatus(0);
		updateDisplays();
		return "Finished.";
	}
	
	Object doLoad(File toloadf) {
		try {
			if (Thread.interrupted()) {
				throw new InterruptedException();
			}
//			setUpApp(xmlFileList.length);
			docViewPanel.removeAll();
			lineViewPanel.removeAll();
			showList.clear();
			docTextPanels.clear();
			docLinePanels.clear();
			resetDisplay = true;
			searchByWordDisplay = false;
			searchByWeightDisplay = false;
			clearSearchDisplay = false;
			searchResultsHash.clear();
			searchTerms.clear();
			FileInputStream fis = new FileInputStream(toloadf);
			ObjectInputStream ins = new ObjectInputStream(fis);
			reader = (xmlReader)ins.readObject();
			ins.close();
			for(int i=0; i<reader.xmlFileList.size();i++) {
				showList.add(new Integer(i+1));
			}
		}
		catch(InterruptedException e) {
			return "Cancelled";
		}
		catch(IOException e) {
			System.out.println("Could not load file: " + toloadf);
			System.out.println(e.getMessage());
			return "Failed to load file";
		}
		catch(ClassNotFoundException e) {
			System.out.println("Could not find requested class in the given data file.");
			return "Failed to load data";
		}
		cancelButton.setEnabled(false);
		colorUsingWords.setEnabled(true);
		colorUsingWeights.setEnabled(true);
		colorUsingWeights.setSelected(true);
		wordSearchButton.setEnabled(true);
		wordSearchField.setText("");
		updateDisplays();
		return "Finished";
	}
	
		
	Object doSave(File savef){
		try {
			if (Thread.interrupted()) {
				throw new InterruptedException();
			}
			savef.createNewFile();
			FileOutputStream fos = new FileOutputStream(savef);
			ObjectOutputStream outs = new ObjectOutputStream(fos);
			outs.writeObject(reader);
			outs.close();
		}
		catch(InterruptedException ie) {
			return "Cancelled";
		}
		catch(IOException ioe) {
			System.out.println("Could not save file: "+ savef);
			System.out.println(ioe.getMessage());
			return "Failed";
		}
		cancelButton.setEnabled(false);
		return "Finished";
	}
	
	void showLegend() {
		Document doc = new DefaultStyledDocument();
		MutableAttributeSet attr = new SimpleAttributeSet();
		//StyleConstants.setAlignment(attr, StyleConstants.ALIGN_CENTER);
		int offset;
		ListIterator wi = searchTerms.listIterator();
		while(wi.hasNext()) {
			String currword = (String)wi.next();
			StyleConstants.setForeground(attr, (Color)searchColorList.get(searchTerms.indexOf(currword)));
			offset = doc.getLength();
			try {
				doc.insertString(offset, currword + " : " + searchTermWeights.get(searchTerms.indexOf(currword)) + " ", attr);
			}
			catch(BadLocationException e) {
				System.out.println("Could not create legend");
				e.printStackTrace();
			}
		}
		
		searchLegendPane.setDocument(doc);
	}
	
	Object doSearch() {
		try {
			//showList.clear();
			if(searchTerms.isEmpty()) {
				JOptionPane.showMessageDialog(null, "Nothing to search for");
				searchTerms.clear();
				searchTermWeights.clear();
				searchResultsHash.clear();
				return "Finished";
			}
			ListIterator wi = searchTerms.listIterator();
			if (Thread.interrupted()) {
				throw new InterruptedException();
			}
			while(wi.hasNext()) {
				int index = wi.nextIndex();
				Map placesMap = (Map)reader.mainWordsHash.get(wi.next());
				if(placesMap != null) {
					//System.out.println(placesMap);
					searchResultsHash = combineWordHashes(searchResultsHash, placesMap, ((Integer)searchTermWeights.get(index)).intValue());
				}
			}
			//System.out.println("Final : " + searchResultsHash.toString());
			if(!searchResultsHash.isEmpty()) {
				if(searchMode == "words") {
					searchByWordDisplay = true;
					searchByWeightDisplay = false;
					resetDisplay = false;
					clearSearchDisplay = false;					
				}
				else if(searchMode == "weights") {
					searchByWeightDisplay = true;
					searchByWordDisplay = false;
					resetDisplay = false;
					clearSearchDisplay = false;					
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "None of the poems contain this word.");
				searchTerms.clear();
				searchTermWeights.clear();
				searchResultsHash.clear();
				return "Finished";
			}
		}
		catch(InterruptedException e){
			return "Cancelled";
		}
		updateDisplays();
		showLegend();
		wordSearchButton.setEnabled(false);
		colorUsingWords.setEnabled(false);
		colorUsingWeights.setEnabled(false);
		hideNonHitsBox.setEnabled(true);
		removeNonHitsBox.setEnabled(true);
		clearSearchButton.setEnabled(true);
		return "Finished";
	}
	
	Object doClear() {
		try {
			if (Thread.interrupted()) {
				throw new InterruptedException();
			}
			searchByWordDisplay = false;
			searchByWeightDisplay = false;
			resetDisplay = false;
			clearSearchDisplay = true;
		}
		catch(InterruptedException e){
			return "Cancelled.";
		}
		try {
			if(displayTabbedPane.getTabCount() > 2) {
				displayTabbedPane.removeTabAt(2);
			}
		}
		catch(IndexOutOfBoundsException e) {
			e.printStackTrace();
			System.out.println(displayTabbedPane.getTabCount());
		}
		filteredLineViewPanel.removeAll();
		lineViewPanel.removeAll();
		updateDisplays();
		searchResultsHash.clear();
		searchTerms.clear();
		searchTermWeights.clear();
		wordSearchButton.setEnabled(true);
		
		hideNonHitsBox.setEnabled(false);
		hideNonHitsBox.setSelected(false);

		removeNonHitsBox.setEnabled(false);
		removeNonHitsBox.setSelected(false);
		
		colorUsingWords.setEnabled(true);
		colorUsingWeights.setEnabled(true);
		
		searchLegendPane.setDocument(new DefaultStyledDocument());
		
		clearSearchButton.setEnabled(false);
		
		wordSearchField.requestFocus();
		wordSearchField.selectAll();

		clearSearchDisplay = false;
		resetDisplay = true;
		return "Finished.";

	}
	
	Object doHide() {
		try {
			if (Thread.interrupted()) {
				throw new InterruptedException();
			}
		}
		catch(InterruptedException e){
			return "Cancelled.";
		}
		updateDisplays();
		hideNonMatchesDisplay = false;
		if(searchMode == "words") {
			searchByWordDisplay = true;
		}
		else if(searchMode == "weights") {
			searchByWeightDisplay = true;
		}
		return "Finished";
	}

	
	ActionListener cancelListener = new ActionListener() {
		public void actionPerformed(ActionEvent e){
			cancelButton.setEnabled(false);
			worker.interrupt();
		}
	};
		
	class emilyFocusListener implements FocusListener {
		public void focusGained(FocusEvent e) {
			Object o = e.getSource();
			if(o instanceof docPane) {
				docPane dp = (docPane)o;
				JPanel docTextPanel = (JPanel)dp.getParent();
				docTextPanel.setBorder(BorderFactory.createLineBorder(Color.red));
			}
			else if(o instanceof linePanel) {
				//System.out.println("LinePanel focussed");
				linePanel lp = (linePanel)o;
				lp.setBorder(BorderFactory.createLineBorder(Color.red));
			}
		}
		
		public void focusLost(FocusEvent e){
			Object o = e.getSource();
			if(o instanceof docPane) {
				docPane dp = (docPane)o;
				JPanel docTextPanel = (JPanel)dp.getParent();
				docTextPanel.setBorder(BorderFactory.createLineBorder(Color.white));
			}
			else if(o instanceof linePanel) {
				linePanel lp = (linePanel)o; 
				lp.setBorder(BorderFactory.createLineBorder(poemBackgroundColor));
			}
		}
	};
	
	void showPoem(Object o) {
		Document d;
		if(o instanceof docPane) {
			docPane dp = (docPane)o;
			d = dp.getDisplayPoemDocument();
			poemTextArea.setDocument(d);
		}
		else if(o instanceof linePanel) {
			linePanel lp = (linePanel)o;
			d = lp.getDisplayPoemDocument();
			poemTextArea.setDocument(d);
		}
	}
	
	MouseListener docTextMouseListener = new MouseListener() {
		public void mouseEntered(MouseEvent me) { }
		public void mouseExited(MouseEvent me) { }
		public void mousePressed(MouseEvent me) { }
		public void mouseReleased(MouseEvent me) { }

		public void mouseClicked(MouseEvent me) {
			docPane clickedDocPane = (docPane)me.getSource();
			if (me.getClickCount() == 2) {
				manuscriptViewer mv = new manuscriptViewer(new Integer(clickedDocPane.getName()), reader); 
				mv.setVisible(true);
			}
			//clickedDocButton.requestFocusInWindow();
			showPoem(clickedDocPane);
		}
	};

	MouseListener docLineMouseListener = new MouseListener() {
		public void mouseEntered(MouseEvent me) { }
		public void mouseExited(MouseEvent me) { }
		public void mousePressed(MouseEvent me) { }
		public void mouseReleased(MouseEvent me) { }

		public void mouseClicked(MouseEvent me) {
			linePanel clickedLinePanel = (linePanel)me.getSource();
			if (me.getClickCount() == 2) {
				manuscriptViewer mv = new manuscriptViewer(new Integer(clickedLinePanel.getName()), reader); 
				mv.setVisible(true);
			}
			//clickedDocButton.requestFocusInWindow();
			showPoem(clickedLinePanel);
		}
	};
		
	class openListener implements ActionListener {
		public void actionPerformed(ActionEvent e){
			statusText.setText("Opening XML files...");
			JFileChooser chooser = new JFileChooser();
			chooser.setMultiSelectionEnabled(true);
			int option = chooser.showOpenDialog(null);
			if(option == JFileChooser.APPROVE_OPTION) {
				final File[] sf = chooser.getSelectedFiles();
				final File xmlPath = chooser.getCurrentDirectory();
				emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				worker = new SwingWorker() {
					public Object construct(){
						return doOpenNew(xmlPath, sf);
					}
					public void finished() {
						emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
						statusText.setText(get().toString());
					}
				};
				worker.start();				
			}
			else {
				statusText.setText("Ready.");
			}
		}
	}
	
	class saveListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			statusText.setText("Saving current data to disk...");
			cancelButton.setEnabled(true);
			JFileChooser chooser = new JFileChooser();
			chooser.setApproveButtonText("Save Data");
			chooser.setMultiSelectionEnabled(false);
			int option = chooser.showSaveDialog(null);
			if(option == JFileChooser.APPROVE_OPTION) {
				final File tosavef = chooser.getSelectedFile();
				emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				saver = new SwingWorker() {
					public Object construct() {
						return doSave(tosavef);
					}
					public void finished() {
						emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
						statusText.setText(get().toString());
					}
				};
				saver.start();
			}
			else {
				statusText.setText("Ready.");
			}
		}
	}
	
	class loadListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			statusText.setText("Loading exising data from disk...");
			cancelButton.setEnabled(true);
			JFileChooser chooser = new JFileChooser();
			chooser.setMultiSelectionEnabled(false);
			chooser.setApproveButtonText("Load Data");
			int option = chooser.showOpenDialog(null);
			if(option == JFileChooser.APPROVE_OPTION) {
				final File toloadf = chooser.getSelectedFile();
				emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				worker = new SwingWorker() {
					public Object construct() {
						return doLoad(toloadf);
					}
					public void finished() {
						emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
						statusText.setText(get().toString());
					}
				};
				worker.start();
			}
			else {
				statusText.setText("Ready.");
			}
		}
	}
	
	class wordSearchListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String term;
			String[] givenList = wordSearchField.getText().split(",");
			for(int i=0;i <givenList.length; i++) {
				String[] parts = givenList[i].split(":");
				if(parts.length == 1) {
					term = parts[0].trim();
					if(!term.equals("")) {
						searchTerms.add(term);
					searchTermWeights.add(new Integer(1));
				}
					}
				else if(parts.length == 2) {
					term = parts[0].trim();
					if(!term.equals("")) {
						searchTerms.add(term);
					}
					if(searchMode == "weights") 
						searchTermWeights.add(new Integer(Integer.parseInt(parts[1])));
					else if (searchMode == "words") 
						searchTermWeights.add(new Integer(1));						
				}
				else {
					System.out.println("Invalid search specification.");
				}
			}
			//System.out.println("searchTerms: " + searchTerms.toString());
			//System.out.println("searchTermWeights: " + searchTermWeights.toString());
			statusText.setText("Searching ...");
			emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
			searcher = new SwingWorker() {
				public Object construct() {
					return doSearch();
				}
				public void finished() {
					emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
					statusText.setText(get().toString());					
				}
			};
			searcher.start();
		}
	}
	
	class clearSearchListener implements ActionListener {
		public void actionPerformed(ActionEvent e){
			statusText.setText("Clearing ...");
			emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
			clearer = new SwingWorker() {
				public Object construct() {
					return doClear();
				}
				public void finished() {
					emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
					statusText.setText(get().toString());
				}
			};
			clearer.start();
		}
	}
	
	class hideNonHitsListener implements ItemListener {
		public void itemStateChanged(ItemEvent e) {
			JCheckBox cb = (JCheckBox)e.getSource();
			if(cb.isEnabled()) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					//lineViewPanel.removeAll();
					if(searchMode == "words") {
						searchByWordDisplay = false;
					}
					else if(searchMode == "weights") {
						searchByWeightDisplay = false;
					}
					hideNonMatchesDisplay = true;
					hideOptionSet = true;
				}
				else {
					searchByWordDisplay = false;
					searchByWeightDisplay = false;
					hideNonMatchesDisplay = true;
					hideOptionSet = false;
				}
				//if(cb.isEnabled()) {
				emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
				worker = new SwingWorker() {
					public Object construct() {
						return doHide();
					}
					public void finished() {
						emily.this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
						statusText.setText(get().toString());
					}
				};
				worker.start();
			}
		}
	}
	
	class removeNonHitsListener implements ItemListener {
		public void itemStateChanged(ItemEvent e) {
			JCheckBox cb = (JCheckBox)e.getSource();
			if (cb.isEnabled()) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					//lineViewPanel.removeAll();
					displayTabbedPane.addTab("Filtered Overview",filteredLineViewPanel);
					displayTabbedPane.setSelectedIndex(2);
					displayTabbedPane.revalidate();
					displayTabbedPane.repaint();
				}
				else {
					//lineViewPanel.removeAll();
					displayTabbedPane.removeTabAt(2);
				}
			}
		}
	}
	
	class searchOptionsListener implements ItemListener {
		public void itemStateChanged(ItemEvent e) {
			AbstractButton b = (AbstractButton)e.getItemSelectable();
			if(b.isEnabled())
				searchMode = b.getActionCommand();
		}
	}
}

