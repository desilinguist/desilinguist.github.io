/*
 * Created on Mar 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Nitin Madnani, nmadnani@umiacs.umd.edu
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Algorithm to parse the text out of the TEI XML file should go
 * something like this :
 * 1) Parse out <text> node from root node
 * 2) Parse out <body> from <text> node
 * 3) Parse out the <div0> node from <body>
 * 4) Find all children of <div0>
 * 5) These children could be <div1> or <lg> or <pb> (with the images) and <p>
 * 6) <lg> has the lines <l> and also <pb> with the images
 */

import org.jdom.*;
import org.jdom.input.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;

public class xmlReader implements Serializable {

	static Map imagesHash;
	static Map wordsHash;
	static TreeMap paraHash;
	static List linesList;
	static SAXBuilder builder;
	
	public Map fileNameHash;
	public Map mainWordsHash;
	public Map hashOfLineLists;
	public Map hashOfImageHashes;
	public Map hashOfPoemLengths;
	public Map poemTextHash;
	public List xmlFileList;
	public File srcFilePath;
	
	private Integer numberOfDocuments;
	
	public xmlReader() {
		//builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser",false);
		fileNameHash = new HashMap();
		mainWordsHash = new HashMap();
		hashOfLineLists = new TreeMap();
		hashOfImageHashes = new TreeMap();
		hashOfPoemLengths = new TreeMap();
		poemTextHash = new TreeMap();
		xmlFileList = new ArrayList();
		builder = new SAXBuilder();
	}
		
	public void setNumberOfDocuments(int ndocs){
		numberOfDocuments = new Integer(ndocs);
	}

	public Integer getNumberOfDocuments(){
		return numberOfDocuments;
	}
	
	public void readXML(File path, File xmlFile, int filenum) {
		
		imagesHash = new TreeMap();
		wordsHash = new HashMap();
		paraHash = new TreeMap();
		linesList = new ArrayList();
		srcFilePath = path;
		
		Integer poemnum = new Integer(filenum+1);
		String xmlFileName = xmlFile.getName();
		xmlFileList.add(xmlFile);
		fileNameHash.put(poemnum, xmlFileName);
		try {
			Document doc = builder.build(xmlFile);
			Element root = doc.getRootElement();
			Element text = root.getChild("text");
			Element body = text.getChild("body");
			Element divZero = body.getChild("div0");

			collectLinesAndParagraphs(divZero);
		}
		catch (JDOMException e) {
			System.out.println(xmlFileName + " is not valid");
			System.out.println(e.getMessage());
			throw new RuntimeException("Could not parse files.");
		}
		catch (IOException e){
			System.out.println("Could not check " + xmlFileName);
			System.out.println("because "+e.getMessage());	
		}
						
		//Now that we have the simple hashes, we add them
		//to the superhashes
		hashOfLineLists.put(poemnum, linesList);
		hashOfPoemLengths.put(poemnum, new Integer(linesList.size()));
		hashOfImageHashes.put(poemnum, imagesHash);
		
		//Also add all the lines of this poem to the poemTextHash
		//to obtain full text
		if(!linesList.isEmpty()) {
			Iterator lineiter = linesList.iterator();
			String poemText = "";
			while(lineiter.hasNext()) {
				String s = (String)lineiter.next();
				poemText += s + "\n";
				//System.out.println(s);
			}
			poemTextHash.put(poemnum, poemText);
		}
		
		//Also assimilate the wordhash produced for each poem
		//into the main wordhash
		if(!wordsHash.isEmpty()) {
			Iterator worditer = wordsHash.keySet().iterator();
			while(worditer.hasNext()) {
				// Iterate over all the words in the poem
				String keyword = (String)worditer.next();
				
				// Get all the line numbers in the current poem
				// where this word occurs
				weightedPositionList newLineNumsList = (weightedPositionList)wordsHash.get(keyword);
				//Set newLineNums  = (Set)wordsHash.get(keyword);
				
				// Check if the main wordhash already contains
				// this word
				if (mainWordsHash.containsKey(keyword)) {
					
					// If yes, then get a reference to the hash stored
					// with this word as key.
					Map wordpoemhash = (Map)mainWordsHash.get(keyword);
					
					if (wordpoemhash.containsKey(poemnum)) {
						//Set existingLineNums = (Set)wordpoemhash.get(poemnum);
						//existingLineNums.addAll(newLineNums);
						weightedPositionList existingLineNumsList = (weightedPositionList)wordpoemhash.get(poemnum);
						existingLineNumsList.combine(newLineNumsList);
					}
					else {
						//Set lineNums = new LinkedHashSet(newLineNums);
						//weightedPositionsList lineNums
						//wordpoemhash.put(poemnum, lineNums);
						wordpoemhash.put(poemnum, newLineNumsList);
					}
				}
				else {
					Map wordpoemhash = new TreeMap();
					wordpoemhash.put(poemnum, newLineNumsList);
					mainWordsHash.put(keyword, wordpoemhash);
				}
			}
		}
	}
	
	public void collectLinesAndParagraphs(Element current) {
		
		// A recursive function that finds all the <l> and <p>
		// elements in all of the given node's children
		
		// Get all level one children
		Pattern punct = Pattern.compile("([,.!-\\'?\"])");
		Matcher m;

		java.util.List allChildren = current.getChildren();
		Iterator iterator = allChildren.iterator();
		while(iterator.hasNext()) {
			Element child = (Element) iterator.next();
			if(child.getName() == "l") {
				try {
					//Add the line with the given linenumber to the hash
					if (child.getAttribute("n") != null) {
//						System.out.println("Found a line");
						Integer linenum = new Integer(child.getAttribute("n").getIntValue());
						Integer linenum2;
						List lc = child.getContent();
						LineTextCollector ltc = new LineTextCollector("");
						ltc.collectText(lc);
						String lineText = LineTextCollector.linestr;
						m = punct.matcher(lineText);
						lineText = m.replaceAll(" $1 ");
						lineText = lineText.replaceAll("\\s+", " ");
						lineText = lineText.trim();
						if(!lineText.equals("")) {
							linesList.add(lineText);
							linenum2 = new Integer(linesList.size());
					
							// Also split the line into words and add the words into the simple
							// word hash for now
							String[] words = lineText.split("\\s+");
							for(int i=0; i<words.length; i++) {
								String currword = words[i].toLowerCase();
								if (wordsHash.containsKey(currword)) {
									//Set positions = (Set)wordsHash.get(currword);
									weightedPositionList wpl = (weightedPositionList)wordsHash.get(currword);
									wpl.add((linenum2));
									//positions.add(linenum2);
								}
								else {
									weightedPositionList wpl = new weightedPositionList();
									//Set positions = new LinkedHashSet();
									wpl.add(linenum2);
									//positions.add(linenum2);
									wordsHash.put(currword, wpl);
								}
							}
						}
					}
				}
				catch(DataConversionException e) {
					System.out.println(e.getMessage());
				}
				catch(NullPointerException e) {
					System.out.println("Tag " + child.getName() + " has a null pointer exception");
					System.out.println(e.getMessage());
				}
			}
			else if(child.getName() == "p") {
				try {
					if (child.getAttribute("n") != null) {
//						System.out.println("Found a paragraph");
						Integer paranum = new Integer(child.getAttribute("n").getIntValue());
						List pc = child.getContent();
						ParaTextCollector ptc = new ParaTextCollector("");
						ptc.collectText(pc);
						String pstr = new String(ParaTextCollector.parastr);
						m = punct.matcher(pstr);
						pstr = m.replaceAll(" $1 ");
						pstr = pstr.replaceAll("[ ]+", " ");
						pstr = pstr.trim();
						String[] lines = pstr.split("\\n");
						Integer linenum2;
						for(int i=0;i<lines.length;i++) {
							linesList.add(lines[i]);
							linenum2 = new Integer(linesList.size());
//							System.out.println("Added line " + linenum2.toString() + ": " + lines[i]);
							String[] words = lines[i].split("\\s+");
							for(int j=0; j<words.length; j++) {
								String currword = words[j].toLowerCase();
//								System.out.println(currword + "in " + lines[i] + "(" + linenum2.toString() + ")");
								if (wordsHash.containsKey(currword)) {
									weightedPositionList wpl = (weightedPositionList)wordsHash.get(currword);
									//Set positions = (Set)wordsHash.get(currword);
									//positions.add(linenum2);
									wpl.add(linenum2);
								}
								else {
									//Set positions = new LinkedHashSet();
									weightedPositionList wpl = new weightedPositionList();
									wpl.add(linenum2);
									//positions.add(linenum2);
									wordsHash.put(currword, wpl);
								}
							}
						}
						imagesHash.putAll(ParaTextCollector.imageHash);
					}
					else {
						continue;
					}
				}
				catch(DataConversionException e) {
					System.out.println(e.getMessage());
				}
			}
			else if(child.getName() == "pb") {
				try {
					Integer pagenum = new Integer(child.getAttribute("n").getIntValue());
					String imagename = child.getAttribute("entity").getValue();
					imagesHash.put(pagenum, imagename);
				}
				catch(DataConversionException e) {
					System.out.println(e.getMessage());
				}
			}
			else {
				collectLinesAndParagraphs(child);
			}
			
		}
	}
}

class LineTextCollector {
	static String linestr;
	
	public LineTextCollector(String initstr) {
		linestr = new String(initstr);
	}
	
	public void collectText(Object o) {
		if (o instanceof Text) {
			//System.out.println("Text");
			Text t= (Text) o;
			linestr += t.getTextNormalize() + " "; 
		}
		else if(o instanceof Element) {
			//System.out.println("Element");
			Element e = (Element) o;
			if(e.getContent() != null) {
				collectText(e.getContent());
			}
		}
		else if(o instanceof List) {
			List l = (List) o;
			//System.out.println(l.toString());
			if(l.size() > 1) {
				collectText(l.get(0));
			//	System.out.println(l.subList(1, l.size()).toString());
				collectText(l.subList(1,l.size()));
			}
			else if(l.size() == 1) {
				collectText(l.get(0));
			}
		}
	}
}

class ParaTextCollector {
	static String parastr;
	static Map imageHash;
	
	public ParaTextCollector(String initstr) {
		parastr = new String(initstr);
		imageHash = new TreeMap();
	}
	
	public void collectText(Object o) {
		if (o instanceof Text) {
			//System.out.println("Text");
			Text t= (Text) o;
			parastr += t.getTextNormalize() + " "; 
		}
		else if(o instanceof Element) {
			//System.out.println("Element");
			Element e = (Element) o;
			if(e.getName() == "lb") {
				parastr += "\n";
			}
			else if(e.getName() == "pb") {
				try {
					Integer pagenum = new Integer(e.getAttribute("n").getIntValue());
					String imagename = e.getAttribute("entity").getValue();
					imageHash.put(pagenum, imagename);
				}
				catch(DataConversionException ex) {
					System.out.println(ex.getMessage());
				}
			}
			
			if(!(e.getName() == "del")) {
				collectText(e.getContent());
			}
		}
		else if(o instanceof List) {
			//System.out.println("List");
			List l = (List) o;
			//System.out.println(l.toString());
			if(l.size() > 1) {
				collectText(l.get(0));
			//	System.out.println(l.subList(1, l.size()).toString());
				collectText(l.subList(1,l.size()));
			}
			else if(l.size() == 1) {
				collectText(l.get(0));
			}
		}
	}
	
}
