/*
 * Created on Apr 27, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author nmadnani
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class layoutParameters {

	public int eachWidth;
	public int eachHeight;
	public int lineWidth;
	public int rectFillWidth;
	public int numRows;
	
	public layoutParameters(int ew, int eh, int lw, int rfw, int nr) {
		eachWidth = ew;
		eachHeight = eh;
		lineWidth = lw;
		rectFillWidth = rfw;
		numRows = nr;
	}
}
