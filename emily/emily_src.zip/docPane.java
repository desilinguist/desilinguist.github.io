import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
/*
 * Created on Apr 24, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author nmadnani
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class docPane extends JTextPane {
	
	private Document displayDocument;
	
	public docPane() {
		super();
	}
	
	public void setPoemDocument(Document doc){
		setDocument(doc);
		//this.revalidate();
	}
	
	public void setDisplayPoemDocument(Document doc) {
		displayDocument = doc;
	}
	
	public void setPoemBackground(Color c) {
		setBackground(c);
	}

	public Document getDisplayPoemDocument() {
		return displayDocument;
	}
	
}
