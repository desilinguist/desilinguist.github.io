/*
 * Created on Apr 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author nmadnani
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

import java.util.*;
import java.io.*;

public class weightedPositionList implements Serializable {

	private List positions;
	private Map weights;
	
	public weightedPositionList() {
		positions = new ArrayList();
		weights = new TreeMap();
	}
	
	public weightedPositionList(List p, Map w) {
		positions = new ArrayList(p);
		weights = new TreeMap(w);
	}
	
	public weightedPositionList(weightedPositionList wpl) {
		positions = new ArrayList(wpl.getPositions());
		weights = new TreeMap(wpl.getWeights());
	}
	
	public weightedPositionList(weightedPositionList wpl, int scaleFactor) {
		positions = new ArrayList(wpl.getPositions());
		weights = new TreeMap(wpl.getWeights());
		Iterator ki = weights.keySet().iterator();
		while(ki.hasNext()) {
			Integer key = (Integer)ki.next();
			Integer newWeight = new Integer(((Integer)weights.get(key)).intValue() * scaleFactor);
			weights.put(key, newWeight);
		}
	}
	
	public void add(Object o) {
		if(positions.contains(o)) {
			Integer storedIndex = new Integer(positions.indexOf(o));
			Integer storedWeight = (Integer)weights.get(storedIndex);
			weights.put(storedIndex, new Integer(storedWeight.intValue()+1));
		}
		else {
			positions.add(o);
			Integer storedIndex = new Integer(positions.indexOf(o));
			weights.put(storedIndex, new Integer(1));
		}
	}

	public void add(Object o, int scaleFactor) {
		if(positions.contains(o)) {
			Integer storedIndex = new Integer(positions.indexOf(o));
			Integer storedWeight = (Integer)weights.get(storedIndex);
			weights.put(storedIndex, new Integer(storedWeight.intValue()+scaleFactor*1));
		}
		else {
			positions.add(o);
			Integer storedIndex = new Integer(positions.indexOf(o));
			weights.put(storedIndex, new Integer(scaleFactor*1));
		}
	}

	
	public boolean contains(Object o) {
		return positions.contains(o);
	}
	
	public Map getWeights() {
		return weights;
	}
	
	public List getPositions() {
		return positions;
	}
	
	public String toString() {
		String retstr = "[";
		Iterator positer = positions.iterator();
		while(positer.hasNext()) {
			Object o = positer.next();
			Integer idx = new Integer(positions.indexOf(o));
			if(weights.containsKey(idx)) {
				retstr += "(" + o.toString() + "," + weights.get(idx).toString() + ") ";
			}
			else {
				retstr += "(" + o.toString() + ",0) ";
			}
		}
		retstr += "]";
		return retstr;
	}
	
	
	public void clear() {
		positions.clear();
		weights.clear();
	}
	
	public void combine(weightedPositionList wpl) {
		List newPositions = wpl.getPositions();
		Iterator positer = newPositions.iterator();
		while(positer.hasNext()) {
			this.add(positer.next());
		}
	}
	
	public void combine(weightedPositionList wpl, int scaleFactor) {
		List newPositions = wpl.getPositions();
		Iterator positer = newPositions.iterator();
		while(positer.hasNext()) {
			this.add(positer.next(), scaleFactor);
		}
	}

	public int getWeight(Object o) throws NullPointerException {
		if(positions.contains(o)) {
			Integer storedIndex = new Integer(positions.indexOf(o));
			return ((Integer)weights.get(storedIndex)).intValue();
		}
		else {
			throw new NullPointerException();
		}
	}
}
